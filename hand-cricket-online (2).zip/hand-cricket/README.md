# 🏏 Hand Cricket Online
### Real-Time Multiplayer Web Game — FSWD Mini Project
**4th Semester | Computer Engineering | VESIT Mumbai | 2025–26**

---

## 📌 Project Overview

Hand Cricket Online is a real-time multiplayer web game built as a Full Stack Web Development (FSWD) Mini Project. Players choose numbers 0–6 each turn — if both pick the same number, the batsman is OUT; otherwise the batsman scores the runs they chose.

---

## 🛠️ Tech Stack

| Layer     | Technology                          |
|-----------|-------------------------------------|
| Frontend  | React.js 18, React Router v6, CSS3  |
| Backend   | Node.js, Express.js                 |
| Real-time | Socket.IO (WebSockets)              |
| Database  | MongoDB with Mongoose ODM           |
| Auth      | JWT (JSON Web Tokens) + bcryptjs    |

---

## 📁 Project Structure

```
hand-cricket-online/
├── server/
│   ├── index.js                  ← Express + Socket.IO server entry
│   ├── models/
│   │   ├── User.js               ← User schema with stats
│   │   └── Match.js              ← Match schema with innings
│   ├── routes/
│   │   ├── auth.js               ← /api/auth (register, login, me)
│   │   └── matches.js            ← /api/matches (history, detail)
│   ├── middleware/
│   │   └── auth.js               ← JWT protect middleware
│   └── socket/
│       └── gameSocket.js         ← All Socket.IO game logic
│
├── client/
│   ├── public/
│   │   └── index.html
│   └── src/
│       ├── App.js                ← Routes + PrivateRoute guard
│       ├── index.js              ← React entry point
│       ├── index.css             ← Global cricket-theme styles
│       ├── context/
│       │   ├── AuthContext.js    ← Auth state + JWT storage
│       │   └── SocketContext.js  ← Socket.IO connection manager
│       ├── components/
│       │   ├── Navbar.js         ← Top navigation bar
│       │   ├── Scoreboard.js     ← Live score display
│       │   ├── TimerRing.js      ← SVG countdown timer
│       │   └── NumPad.js         ← 0-6 number selection pad
│       └── pages/
│           ├── LoginPage.js      ← Login / Sign Up
│           ├── Dashboard.js      ← Main menu + stats
│           ├── CreateRoom.js     ← Host a room + room code
│           ├── JoinRoom.js       ← Join with room code
│           ├── GamePage.js       ← Live gameplay screen
│           ├── ResultPage.js     ← Winner + match summary
│           └── HistoryPage.js    ← Match history + detail
│
├── .env.example                  ← Environment variable template
├── package.json                  ← Root (server) dependencies
└── README.md
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js v18+ and npm
- MongoDB running locally (`mongod`) **or** a MongoDB Atlas URI

### 1. Clone the repository
```bash
git clone https://github.com/your-username/hand-cricket-online.git
cd hand-cricket-online
```

### 2. Set up environment variables
```bash
cp .env.example .env
# Edit .env and set your MONGO_URI and JWT_SECRET
```

### 3. Install server dependencies
```bash
npm install
```

### 4. Install client dependencies
```bash
cd client && npm install && cd ..
```

### 5. Run both server + client (development)
```bash
npm run dev:all
```

Or run them separately:
```bash
# Terminal 1 – backend
npm run dev

# Terminal 2 – frontend
cd client && npm start
```

The app opens at **http://localhost:3000**  
The API runs at **http://localhost:5000**

---

## 🎮 How to Play

### Multiplayer
1. **Player A** → Dashboard → Create Room → share the 6-character code
2. **Player B** → Dashboard → Join Room → enter the code
3. Game starts automatically when both players are in

### vs Computer
1. Dashboard → **vs Computer** — starts instantly, no room needed

### Gameplay Rules
- 2 innings, 6 balls each
- Each turn: both players secretly pick a number from **0 to 6**
- Numbers revealed simultaneously
- **Same number = OUT** (wicket falls, innings ends)
- **Different numbers = batsman scores their own picked number**
- After inning 1: roles swap, inning 2 has a target
- Highest score after 2 innings wins

---

## 🔌 Socket.IO Events

| Event              | Direction     | Description                        |
|--------------------|---------------|------------------------------------|
| `create_room`      | Client→Server | Host creates a new room            |
| `room_created`     | Server→Client | Returns generated room code        |
| `join_room`        | Client→Server | Guest joins with a code            |
| `start_vs_computer`| Client→Server | Start single-player vs AI          |
| `game_start`       | Server→Client | Match begins, sends initial state  |
| `player_pick`      | Client→Server | Player submits their number        |
| `pick_registered`  | Server→Client | Confirms pick was received         |
| `turn_start`       | Server→Client | New turn begins, timer resets      |
| `timer_tick`       | Server→Client | Countdown tick (every 1s)          |
| `turn_result`      | Server→Client | Both picks revealed + outcome      |
| `inning_change`    | Server→Client | Inning 1 ends, inning 2 starts     |
| `game_over`        | Server→Client | Match complete, sends result       |
| `opponent_disconnected` | Server→Client | Other player left              |

---

## 📡 REST API Endpoints

| Method | Endpoint               | Auth | Description              |
|--------|------------------------|------|--------------------------|
| POST   | `/api/auth/register`   | No   | Register new user        |
| POST   | `/api/auth/login`      | No   | Login, returns JWT token |
| GET    | `/api/auth/me`         | Yes  | Get current user + stats |
| GET    | `/api/matches/history` | Yes  | Get last 20 matches      |
| GET    | `/api/matches/:id`     | Yes  | Get single match detail  |
| GET    | `/api/health`          | No   | Server health check      |

---

## 👥 Team / Author

| Name | Roll No | Contribution |
|------|---------|--------------|
| _(your name)_ | _(roll no)_ | Full Stack Development |

**Guide:** _(Faculty name)_  
**Institution:** Vivekanand Education Society's Institute of Technology (VESIT), Mumbai  
**Academic Year:** 2025–26

---

## 📸 Screenshots

> _Add screenshots of Login, Dashboard, Game Screen, Result, and History pages here_

---

## 📄 License
This project is developed for academic purposes at VESIT. All rights reserved.
