import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => { logout(); navigate('/login'); };

  const isGame = location.pathname === '/game';

  return (
    <nav className="navbar">
      <div
        className="navbar-logo"
        style={{ cursor: 'pointer' }}
        onClick={() => !isGame && navigate('/dashboard')}
      >
        HAND<span style={{ color: '#7ec842' }}>CRICKET</span>
      </div>

      <div className="navbar-right">
        {!isGame && (
          <>
            <span style={{ fontSize: '0.82rem', color: 'rgba(255,255,255,0.45)' }}>
              {user?.username}
            </span>
            <div className="avatar">{user?.username?.[0]?.toUpperCase()}</div>
            <button className="btn btn-secondary btn-sm" onClick={handleLogout}>
              Logout
            </button>
          </>
        )}
        {isGame && (
          <span style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.35)' }}>
            🏏 Match in progress
          </span>
        )}
      </div>
    </nav>
  );
}
