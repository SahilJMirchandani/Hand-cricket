import React from 'react';

const NUMBERS = [0, 1, 2, 3, 4, 5, 6];

export default function NumPad({ onSelect, selected, disabled }) {
  return (
    <div className="num-pad">
      {NUMBERS.map((n) => (
        <button
          key={n}
          className={[
            'num-btn',
            n === 0 ? 'zero' : '',
            selected === n ? 'selected' : '',
          ].join(' ')}
          onClick={() => onSelect(n)}
          disabled={disabled || selected !== null}
          aria-label={n === 0 ? 'OUT' : `${n} runs`}
        >
          {n}
        </button>
      ))}
    </div>
  );
}
