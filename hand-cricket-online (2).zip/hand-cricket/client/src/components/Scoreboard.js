import React from 'react';

export default function Scoreboard({
  player1Name, player2Name,
  player1Score, player2Score,
  balls, totalBalls, wickets, maxWickets,
  inning, target,
  activeBatter, // 'player1' | 'player2'
}) {
  return (
    <div className="card" style={{ marginBottom: 12 }}>
      <div className="scoreboard">
        <div>
          <div className="p-name">{player1Name}</div>
          <div className={`p-runs${activeBatter === 'player1' ? ' active' : ''}`}>
            {player1Score}
          </div>
          <div className="p-meta">
            {activeBatter === 'player1' ? `${balls}/${totalBalls} balls` : '—'}
          </div>
        </div>

        <div className="vs-divider">VS</div>

        <div>
          <div className="p-name">{player2Name}</div>
          <div className={`p-runs${activeBatter === 'player2' ? ' active' : ''}`}>
            {player2Score}
          </div>
          <div className="p-meta">
            {activeBatter === 'player2' ? `${balls}/${totalBalls} balls` : '—'}
          </div>
        </div>
      </div>

      <div className="divider" style={{ margin: '12px 0' }} />

      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem' }}>
        <span className="text-muted">
          Wickets: <strong style={{ color: 'var(--red)' }}>{wickets}/{maxWickets}</strong>
        </span>
        <span className="text-muted">
          Balls: <strong style={{ color: 'var(--white)' }}>{balls}/{totalBalls}</strong>
        </span>
        <span className="text-muted">
          Target: <strong style={{ color: 'var(--gold)' }}>
            {inning === 2 && target ? target : '—'}
          </strong>
        </span>
      </div>
    </div>
  );
}
