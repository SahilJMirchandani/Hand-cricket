import React from 'react';

export default function TimerRing({ seconds, max = 5 }) {
  const r = 28;
  const circ = 2 * Math.PI * r;
  const offset = circ - (seconds / max) * circ;
  const danger = seconds <= 2;

  return (
    <div className="timer-wrap">
      <div className="timer-ring">
        <svg width="68" height="68" viewBox="0 0 68 68">
          <circle
            cx="34" cy="34" r={r}
            fill="none"
            stroke="rgba(255,255,255,0.07)"
            strokeWidth="5"
          />
          <circle
            cx="34" cy="34" r={r}
            fill="none"
            stroke={danger ? 'var(--red)' : 'var(--lime)'}
            strokeWidth="5"
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 0.9s linear, stroke 0.3s' }}
          />
        </svg>
        <div className="timer-num" style={{ color: danger ? 'var(--red)' : 'var(--white)' }}>
          {seconds}
        </div>
      </div>
    </div>
  );
}
