import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSocket } from '../context/SocketContext';

export default function CreateRoom() {
  const { socket }    = useSocket();
  const navigate      = useNavigate();
  const [code, setCode]       = useState('');
  const [copied, setCopied]   = useState(false);
  const [error, setError]     = useState('');

  useEffect(() => {
    if (!socket) return;

    socket.emit('create_room');

    socket.on('room_created', ({ code: c }) => setCode(c));

    socket.on('game_start', (data) => {
      navigate('/game', { state: data });
    });

    socket.on('error', ({ message }) => setError(message));

    return () => {
      socket.off('room_created');
      socket.off('game_start');
      socket.off('error');
    };
  }, [socket, navigate]);

  const copy = () => {
    navigator.clipboard?.writeText(code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="screen screen-padded">
      <div className="card" style={{ maxWidth: 440, textAlign: 'center' }}>
        <div className="page-title">🏟️ Create Room</div>
        <p className="text-muted" style={{ marginBottom: 6 }}>
          Share this code with your opponent
        </p>

        {error && <div className="alert alert-error" style={{ marginTop: 12 }}>{error}</div>}

        {code ? (
          <>
            <div className="room-code">{code.slice(0, 3)} {code.slice(3)}</div>
            <button className="btn btn-secondary btn-full" style={{ marginBottom: 14 }} onClick={copy}>
              {copied ? '✓ Copied!' : '📋 Copy Code'}
            </button>
            <hr className="divider" />
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'center', marginBottom: 20 }}>
              <span className="blink text-lime" style={{ fontSize: '0.8rem' }}>●</span>
              <span className="text-muted" style={{ fontSize: '0.88rem' }}>Waiting for opponent to join…</span>
            </div>
          </>
        ) : (
          <div style={{ padding: '24px 0', color: 'rgba(255,255,255,0.3)', fontSize: '0.9rem' }}>
            Generating room…
          </div>
        )}

        <button className="btn btn-secondary btn-full" onClick={() => navigate('/dashboard')}>
          ← Back to Dashboard
        </button>
      </div>
    </div>
  );
}
