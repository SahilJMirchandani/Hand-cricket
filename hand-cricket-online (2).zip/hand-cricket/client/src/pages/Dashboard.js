import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';

export default function Dashboard() {
  const { user }    = useAuth();
  const { socket }  = useSocket();
  const navigate    = useNavigate();

  const stats = user?.stats || {};

  const batAvg = stats.totalBallsFaced
    ? ((stats.totalRunsScored || 0) / (stats.totalBallsFaced / 6)).toFixed(1)
    : '0.0';
  const bowlAvg = stats.totalWicketsTaken
    ? ((stats.totalRunsScored || 0) / stats.totalWicketsTaken).toFixed(1)
    : '0.0';

  const statCards = [
    { val: stats.totalMatches || 0,  lbl: 'Matches'    },
    { val: stats.wins        || 0,   lbl: 'Wins'       },
    { val: stats.losses      || 0,   lbl: 'Losses'     },
    { val: stats.bestScore   || 0,   lbl: 'Best Score' },
    { val: batAvg,                   lbl: 'Bat Avg'    },
    { val: bowlAvg,                  lbl: 'Bowl Avg'   },
  ];

  const handleVsComputer = () => {
    if (!socket) return alert('Not connected to server');
    socket.emit('start_vs_computer');
    socket.once('game_start', (data) => {
      navigate('/game', { state: { ...data, isVsComputer: true } });
    });
  };

  const menuItems = [
    { icon: '🏟️', title: 'Create Room',   desc: 'Host a multiplayer match', action: () => navigate('/create-room') },
    { icon: '🎟️', title: 'Join Room',     desc: 'Enter a room code',        action: () => navigate('/join-room')   },
    { icon: '🤖', title: 'vs Computer',   desc: 'Practice offline with AI', action: handleVsComputer               },
    { icon: '📋', title: 'Match History', desc: 'View your past games',     action: () => navigate('/history')     },
  ];

  return (
    <div className="screen screen-padded">
      <div style={{ width: '100%', maxWidth: 680 }}>

        {/* Greeting */}
        <div style={{ marginBottom: 22 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 3 }}>
            <span style={{ fontSize: '1.5rem' }}>👋</span>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', letterSpacing: '0.03em' }}>
              Welcome back,&nbsp;<span className="text-lime">{user?.username}</span>
            </h2>
          </div>
          <p className="text-muted">Ready for your next innings?</p>
        </div>

        {/* Stats */}
        <div className="stats-grid" style={{ marginBottom: 20 }}>
          {statCards.map((s) => (
            <div className="stat-card" key={s.lbl}>
              <div className="stat-val">{s.val}</div>
              <div className="stat-lbl">{s.lbl}</div>
            </div>
          ))}
        </div>

        {/* Menu */}
        <div className="menu-grid">
          {menuItems.map((m) => (
            <div className="menu-card" key={m.title} onClick={m.action} role="button" tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && m.action()}>
              <div className="menu-icon">{m.icon}</div>
              <div className="menu-title">{m.title}</div>
              <div className="menu-desc">{m.desc}</div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
