import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useSocket } from '../context/SocketContext';
import { useAuth }   from '../context/AuthContext';
import Scoreboard    from '../components/Scoreboard';
import TimerRing     from '../components/TimerRing';
import NumPad        from '../components/NumPad';

const TOTAL_BALLS  = 6;
const MAX_WICKETS  = 1;
const TURN_SECONDS = 5;

export default function GamePage() {
  const location  = useLocation();
  const navigate  = useNavigate();
  const { socket } = useSocket();
  const { user }   = useAuth();

  const initData = location.state;

  // ── Game state ──────────────────────────────────────────────
  const [roomCode,    setRoomCode]   = useState(initData?.roomCode || '');
  const [inning,      setInning]     = useState(initData?.inning || 1);
  const [batting,     setBatting]    = useState(initData?.batting || 'host');
  const [hostScore,   setHostScore]  = useState(0);
  const [guestScore,  setGuestScore] = useState(0);
  const [balls,       setBalls]      = useState(0);
  const [wickets,     setWickets]    = useState(0);
  const [target,      setTarget]     = useState(null);

  // Turn state
  const [timer,       setTimer]      = useState(TURN_SECONDS);
  const [myPick,      setMyPick]     = useState(null);
  const [oppPick,     setOppPick]    = useState(null);
  const [outcome,     setOutcome]    = useState(null); // { type, runsThisBall }
  const [phase,       setPhase]      = useState('pick'); // pick | reveal
  const [inningMsg,   setInningMsg]  = useState('');
  const [statusMsg,   setStatusMsg]  = useState('');

  const hostUser  = initData?.hostUser;
  const guestUser = initData?.guestUser;
  const isVsCom   = initData?.isVsComputer;

  // Determine if I am host
  const amHost = hostUser?.id === user?._id || hostUser?.username === user?.username;

  const myName  = amHost ? hostUser?.username : guestUser?.username;
  const oppName = amHost ? guestUser?.username : hostUser?.username;

  // Which player's score is "mine"
  const myScore  = amHost ? hostScore : guestScore;
  const oppScore = amHost ? guestScore : hostScore;

  // Who is batting in display terms
  const activeBatter = (() => {
    if (batting === 'host')  return amHost ? 'player1' : 'player2';
    return amHost ? 'player2' : 'player1';
  })();

  const iAmBatting = (batting === 'host' && amHost) || (batting === 'guest' && !amHost);

  const revealTimeout = useRef(null);

  const resetTurn = useCallback(() => {
    setMyPick(null);
    setOppPick(null);
    setOutcome(null);
    setPhase('pick');
  }, []);

  // ── Socket listeners ────────────────────────────────────────
  useEffect(() => {
    if (!socket || !initData) { navigate('/dashboard'); return; }

    socket.on('turn_start', ({ seconds }) => {
      setTimer(seconds);
      resetTurn();
    });

    socket.on('timer_tick', ({ seconds }) => setTimer(seconds));

    socket.on('pick_registered', () => {
      // Visual feedback handled by myPick state
    });

    socket.on('turn_result', (data) => {
      setHostScore(data.hostScore);
      setGuestScore(data.guestScore);
      setBalls(data.balls);
      setWickets(data.wickets);
      setOppPick(amHost ? data.guestPick : data.hostPick);
      setMyPick(amHost ? data.hostPick : data.guestPick);
      setOutcome({ type: data.outcome, runsThisBall: data.runsThisBall });
      setPhase('reveal');
    });

    socket.on('inning_change', (data) => {
      setInning(data.inning);
      setBatting(data.batting);
      setBalls(0);
      setWickets(0);
      setTarget(data.target);
      const newBatter = data.batting === 'host' ? hostUser?.username : guestUser?.username;
      setInningMsg(`Inning 2 — ${newBatter} batting | Target: ${data.target}`);
      setTimeout(() => setInningMsg(''), 3500);
      resetTurn();
    });

    socket.on('game_over', (data) => {
      clearTimeout(revealTimeout.current);
      navigate('/result', { state: data });
    });

    socket.on('opponent_disconnected', ({ username }) => {
      setStatusMsg(`${username} disconnected. Match ended.`);
      setTimeout(() => navigate('/dashboard'), 3000);
    });

    return () => {
      socket.off('turn_start');
      socket.off('timer_tick');
      socket.off('pick_registered');
      socket.off('turn_result');
      socket.off('inning_change');
      socket.off('game_over');
      socket.off('opponent_disconnected');
    };
  }, [socket, navigate, amHost, hostUser, guestUser, initData, resetTurn]);

  const handlePick = (n) => {
    if (phase !== 'pick' || myPick !== null) return;
    setMyPick(n);
    socket.emit('player_pick', { code: roomCode, pick: n });
  };

  if (!initData) return null;

  const battingLabel = batting === 'host' ? hostUser?.username : guestUser?.username;

  return (
    <div className="screen screen-padded" style={{ justifyContent: 'flex-start', paddingTop: 80 }}>
      <div style={{ width: '100%', maxWidth: 540 }}>

        {/* Inning badge */}
        <div style={{ textAlign: 'center', marginBottom: 14 }}>
          <span className="inning-badge">
            Inning {inning} · {battingLabel} Batting
          </span>
        </div>

        {/* Inning change message */}
        {inningMsg && (
          <div className="alert alert-info" style={{ textAlign: 'center', marginBottom: 12 }}>
            {inningMsg}
          </div>
        )}

        {/* Status/disconnect message */}
        {statusMsg && (
          <div className="alert alert-error" style={{ textAlign: 'center', marginBottom: 12 }}>
            {statusMsg}
          </div>
        )}

        {/* Scoreboard */}
        <Scoreboard
          player1Name={myName}
          player2Name={oppName}
          player1Score={myScore}
          player2Score={oppScore}
          balls={balls}
          totalBalls={TOTAL_BALLS}
          wickets={wickets}
          maxWickets={MAX_WICKETS}
          inning={inning}
          target={target}
          activeBatter={activeBatter}
        />

        {/* Timer */}
        <TimerRing seconds={timer} max={TURN_SECONDS} />

        {/* Number Pad Card */}
        <div className="card">
          <p className="text-muted text-center" style={{ fontSize: '0.83rem', marginBottom: 12 }}>
            {phase === 'pick'
              ? iAmBatting
                ? 'You bat — pick a number (0 = OUT)'
                : 'You bowl — pick a number (match = wicket!)'
              : 'Revealing picks…'}
          </p>

          <NumPad onSelect={handlePick} selected={myPick} disabled={phase !== 'pick'} />

          {/* Reveal section */}
          {phase === 'reveal' && myPick !== null && (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 14 }}>
                <div style={{ textAlign: 'center', background: 'rgba(255,255,255,0.05)', borderRadius: 10, padding: '10px 0' }}>
                  <div className="text-muted" style={{ fontSize: '0.75rem', marginBottom: 4 }}>You played</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', color: 'var(--lime)' }}>
                    {myPick}
                  </div>
                </div>
                <div style={{ textAlign: 'center', background: 'rgba(255,255,255,0.05)', borderRadius: 10, padding: '10px 0' }}>
                  <div className="text-muted" style={{ fontSize: '0.75rem', marginBottom: 4 }}>
                    {isVsCom ? 'Computer' : 'Opponent'}
                  </div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', color: 'var(--white)' }}>
                    {oppPick ?? '?'}
                  </div>
                </div>
              </div>

              {outcome && (
                <div className={`result-chip ${outcome.type === 'out' ? 'chip-out' : 'chip-runs'}`}>
                  {outcome.type === 'out'
                    ? '💀 OUT! Both picked the same number!'
                    : `+${outcome.runsThisBall} run${outcome.runsThisBall !== 1 ? 's' : ''} scored!`}
                </div>
              )}
            </>
          )}

          {/* Waiting for opponent indicator */}
          {phase === 'pick' && myPick !== null && (
            <div style={{ textAlign: 'center', marginTop: 14 }}>
              <span className="blink text-lime" style={{ fontSize: '0.8rem' }}>●</span>
              <span className="text-muted" style={{ fontSize: '0.85rem', marginLeft: 7 }}>
                Waiting for {isVsCom ? 'computer' : 'opponent'}…
              </span>
            </div>
          )}
        </div>

        {/* Ball history strip */}
        <div style={{ marginTop: 14, display: 'flex', gap: 6, justifyContent: 'center', flexWrap: 'wrap' }}>
          {Array.from({ length: TOTAL_BALLS }).map((_, i) => (
            <div
              key={i}
              style={{
                width: 28, height: 28, borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.7rem', fontWeight: 700,
                background: i < balls ? 'rgba(126,200,66,0.15)' : 'rgba(255,255,255,0.05)',
                border: `1px solid ${i < balls ? 'rgba(126,200,66,0.35)' : 'rgba(255,255,255,0.08)'}`,
                color: i < balls ? 'var(--lime)' : 'rgba(255,255,255,0.2)',
              }}
            >
              {i < balls ? i + 1 : ''}
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
