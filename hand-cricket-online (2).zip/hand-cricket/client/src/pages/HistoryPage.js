import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function HistoryPage() {
  const navigate = useNavigate();
  const [matches,  setMatches]  = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState('');

  useEffect(() => {
    axios.get('/api/matches/history')
      .then(({ data }) => setMatches(data.matches))
      .catch(() => setError('Failed to load match history'))
      .finally(() => setLoading(false));
  }, []);

  const fmtDate = (d) =>
    new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  return (
    <div className="screen screen-padded" style={{ justifyContent: 'flex-start', paddingTop: 82 }}>
      <div style={{ width: '100%', maxWidth: 780 }}>

        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div>
            <div className="page-title">📋 Match History</div>
            <p className="text-muted">Your last 20 matches</p>
          </div>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate('/dashboard')}>
            ← Dashboard
          </button>
        </div>

        {loading && <p className="text-muted text-center" style={{ padding: 32 }}>Loading…</p>}
        {error   && <div className="alert alert-error">{error}</div>}

        {!loading && !error && matches.length === 0 && (
          <div className="card" style={{ textAlign: 'center', padding: 48 }}>
            <p style={{ fontSize: '2rem', marginBottom: 10 }}>🏏</p>
            <p className="text-muted">No matches yet. Play your first game!</p>
            <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={() => navigate('/dashboard')}>
              Play Now
            </button>
          </div>
        )}

        {!loading && matches.length > 0 && (
          <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 1fr' : '1fr', gap: 16, alignItems: 'start' }}>

            {/* Table */}
            <div className="card" style={{ padding: '0 0 4px' }}>
              <table className="hist-table">
                <thead>
                  <tr>
                    <th>Opponent</th>
                    <th>Result</th>
                    <th>Score</th>
                    <th>SR</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {matches.map((m) => (
                    <tr
                      key={m._id}
                      onClick={() => setSelected(selected?._id === m._id ? null : m)}
                      style={{ background: selected?._id === m._id ? 'rgba(126,200,66,0.06)' : undefined }}
                    >
                      <td>
                        <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{m.opponent}</div>
                        <div style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.35)', marginTop: 1 }}>
                          {m.isVsComputer ? '🤖 vs Computer' : '👥 Multiplayer'}
                        </div>
                      </td>
                      <td>
                        <span className={`badge badge-${m.result.toLowerCase()}`}>
                          {m.result}
                        </span>
                      </td>
                      <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}>
                        {m.myScore}–{m.oppScore}
                      </td>
                      <td style={{ color: 'var(--lime)', fontWeight: 600, fontSize: '0.85rem' }}>
                        {m.strikeRate}
                      </td>
                      <td className="text-muted" style={{ fontSize: '0.8rem', whiteSpace: 'nowrap' }}>
                        {fmtDate(m.date)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Detail Panel */}
            {selected && (
              <div className="card" style={{ animation: 'fadeUp 0.25s ease both' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                  <div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--lime)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>
                      Match Detail
                    </div>
                    <div style={{ fontSize: '1rem', fontWeight: 700, marginTop: 3 }}>vs {selected.opponent}</div>
                    <div className="text-muted" style={{ fontSize: '0.78rem', marginTop: 2 }}>{fmtDate(selected.date)}</div>
                  </div>
                  <span className={`badge badge-${selected.result.toLowerCase()}`} style={{ fontSize: '0.8rem' }}>
                    {selected.result}
                  </span>
                </div>

                <hr className="divider" />

                <div className="stats-grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 16 }}>
                  <div className="stat-card">
                    <div className="stat-val">{selected.myScore}</div>
                    <div className="stat-lbl">Runs Scored</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-val" style={{ color: 'var(--red)' }}>{selected.oppScore}</div>
                    <div className="stat-lbl">Opp. Runs</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-val">{selected.wickets}</div>
                    <div className="stat-lbl">Wickets Taken</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-val" style={{ fontSize: '1.4rem' }}>{selected.strikeRate}</div>
                    <div className="stat-lbl">Strike Rate</div>
                  </div>
                </div>

                <div style={{ background: 'rgba(255,255,255,0.03)', borderRadius: 10, padding: '12px 14px' }}>
                  <p style={{ fontSize: '0.72rem', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>
                    Performance
                  </p>
                  {[
                    { label: 'Batting Avg',  value: selected.myScore > 0 ? (selected.myScore / 1).toFixed(1) : '0.0' },
                    { label: 'Mode',         value: selected.isVsComputer ? 'vs Computer' : 'Multiplayer' },
                    { label: 'Result',       value: selected.result },
                    { label: 'Margin',       value: `${Math.abs(selected.myScore - selected.oppScore)} runs` },
                  ].map((r) => (
                    <div key={r.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 7, fontSize: '0.85rem' }}>
                      <span className="text-muted">{r.label}</span>
                      <span style={{ color: 'var(--white)', fontWeight: 500 }}>{r.value}</span>
                    </div>
                  ))}
                </div>

                <button
                  className="btn btn-secondary btn-full btn-sm"
                  style={{ marginTop: 14 }}
                  onClick={() => setSelected(null)}
                >
                  Close Detail
                </button>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
