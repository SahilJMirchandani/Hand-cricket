import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSocket } from '../context/SocketContext';

export default function JoinRoom() {
  const { socket }  = useSocket();
  const navigate    = useNavigate();
  const [code, setCode]     = useState('');
  const [error, setError]   = useState('');
  const [joining, setJoining] = useState(false);

  useEffect(() => {
    if (!socket) return;

    socket.on('game_start', (data) => {
      navigate('/game', { state: data });
    });

    socket.on('error', ({ message }) => {
      setError(message);
      setJoining(false);
    });

    return () => {
      socket.off('game_start');
      socket.off('error');
    };
  }, [socket, navigate]);

  const join = () => {
    const trimmed = code.replace(/\s/g, '').toUpperCase();
    if (trimmed.length < 5) { setError('Please enter a valid room code'); return; }
    setError('');
    setJoining(true);
    socket.emit('join_room', { code: trimmed });
  };

  return (
    <div className="screen screen-padded">
      <div className="card" style={{ maxWidth: 440, textAlign: 'center' }}>
        <div className="page-title">🎟️ Join Room</div>
        <p className="text-muted" style={{ marginBottom: 20 }}>
          Enter the room code your friend shared
        </p>

        {error && <div className="alert alert-error">{error}</div>}

        <div className="form-group">
          <label className="form-label">Room Code</label>
          <input
            className="form-input"
            placeholder="e.g. A3X 9KZ"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            onKeyDown={(e) => e.key === 'Enter' && join()}
            style={{ textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: '1.5rem', letterSpacing: '0.18em' }}
            maxLength={8}
          />
        </div>

        <button
          className="btn btn-primary btn-full btn-lg"
          style={{ marginBottom: 10 }}
          onClick={join}
          disabled={joining || !socket}
        >
          {joining ? '⏳ Connecting…' : '🏏 Join Match'}
        </button>

        <button className="btn btn-secondary btn-full" onClick={() => navigate('/dashboard')}>
          ← Back to Dashboard
        </button>
      </div>
    </div>
  );
}
