import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const { login, register } = useAuth();
  const [mode, setMode]       = useState('login');
  const [form, setForm]       = useState({ username: '', email: '', password: '' });
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (mode === 'login') {
        await login(form.email, form.password);
      } else {
        if (!form.username.trim()) { setError('Username is required'); setLoading(false); return; }
        if (form.password.length < 6) { setError('Password must be at least 6 characters'); setLoading(false); return; }
        await register(form.username.trim(), form.email, form.password);
      }
    } catch (err) {
      setError(err?.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="screen">
      <div style={{ width: '100%', maxWidth: 420 }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div className="logo-text">HAND<span>CRICKET</span></div>
          <p className="text-muted" style={{ marginTop: 6 }}>Real-Time Multiplayer · VESIT FSWD Mini Project</p>
        </div>
        <div className="card">
          <div style={{ display: 'flex', gap: 8, marginBottom: 22 }}>
            <button className={`btn btn-full${mode === 'login' ? ' btn-primary' : ' btn-secondary'}`} onClick={() => { setMode('login'); setError(''); }} type="button">Login</button>
            <button className={`btn btn-full${mode === 'signup' ? ' btn-primary' : ' btn-secondary'}`} onClick={() => { setMode('signup'); setError(''); }} type="button">Sign Up</button>
          </div>
          {error && <div className="alert alert-error">{error}</div>}
          <form onSubmit={submit}>
            {mode === 'signup' && (
              <div className="form-group">
                <label className="form-label">Username</label>
                <input className="form-input" name="username" placeholder="Choose a username" value={form.username} onChange={change} autoComplete="username" maxLength={20} />
              </div>
            )}
            <div className="form-group">
              <label className="form-label">Email</label>
              <input className="form-input" type="email" name="email" placeholder="you@example.com" value={form.email} onChange={change} autoComplete="email" />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input className="form-input" type="password" name="password" placeholder={mode === 'signup' ? 'At least 6 characters' : '••••••••'} value={form.password} onChange={change} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
            </div>
            <button className="btn btn-primary btn-full btn-lg" style={{ marginTop: 6 }} type="submit" disabled={loading}>
              {loading ? 'Please wait…' : mode === 'login' ? '🏏  Login' : '🚀  Create Account'}
            </button>
          </form>
          <p style={{ textAlign: 'center', marginTop: 20, fontSize: '0.72rem', color: 'rgba(255,255,255,0.2)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
            FSWD Mini Project · 4th Sem CE · VESIT · 2025–26
          </p>
        </div>
      </div>
    </div>
  );
}
