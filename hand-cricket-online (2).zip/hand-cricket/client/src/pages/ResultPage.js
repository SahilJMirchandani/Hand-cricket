import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function ResultPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, refreshUser } = useAuth();

  const data = location.state;

  // Refresh stats after match
  React.useEffect(() => { refreshUser(); }, []); // eslint-disable-line

  if (!data) { navigate('/dashboard'); return null; }

  const { winner, hostScore, guestScore, hostUser, guestUser, isVsComputer } = data;

  const isWinner = winner === user?.username;
  const isDraw   = winner === 'draw';

  const resultLabel = isDraw ? "It's a Draw!" : isWinner ? 'You Won! 🎉' : `${winner} Won`;

  const margin = Math.abs(hostScore - guestScore);

  const summaryLines = [
    { label: 'Final Score',    value: `${hostUser?.username}: ${hostScore} vs ${guestUser?.username}: ${guestScore}` },
    { label: 'Winning Margin', value: isDraw ? '—' : `${margin} run${margin !== 1 ? 's' : ''}` },
    { label: 'Game Mode',      value: isVsComputer ? 'vs Computer' : 'Multiplayer' },
  ];

  return (
    <div className="screen screen-padded">
      <div style={{ width: '100%', maxWidth: 480 }}>
        <div className="card" style={{ textAlign: 'center' }}>

          {/* Trophy / emoji */}
          <div className="trophy">{isDraw ? '🤝' : isWinner ? '🏆' : '😔'}</div>

          <p className="text-muted" style={{ fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 4 }}>
            {isDraw ? 'Result' : isWinner ? 'Winner' : 'Winner'}
          </p>
          <div className="winner-name">{isDraw ? "It's a Draw!" : winner}</div>

          {!isDraw && (
            <p style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.4)', marginTop: 6 }}>
              {isWinner ? `You won by ${margin} run${margin !== 1 ? 's' : ''}!` : `You lost by ${margin} run${margin !== 1 ? 's' : ''}`}
            </p>
          )}

          {/* Final Scores */}
          <div className="final-grid">
            <div className="fscore">
              <div className="runs" style={{ color: hostScore >= guestScore ? 'var(--lime)' : 'var(--red)' }}>
                {hostScore}
              </div>
              <div className="name">{hostUser?.username}</div>
            </div>
            <div className="fscore">
              <div className="runs" style={{ color: guestScore >= hostScore ? 'var(--lime)' : 'var(--red)' }}>
                {guestScore}
              </div>
              <div className="name">{guestUser?.username}</div>
            </div>
          </div>

          {/* Summary */}
          <div style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
            padding: '14px 16px',
            marginBottom: 20,
            textAlign: 'left',
          }}>
            <p style={{ fontSize: '0.72rem', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>
              Match Summary
            </p>
            {summaryLines.map((l) => (
              <div key={l.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 7, fontSize: '0.87rem' }}>
                <span className="text-muted">{l.label}</span>
                <span style={{ color: 'var(--white)', fontWeight: 500 }}>{l.value}</span>
              </div>
            ))}
          </div>

          {/* Actions */}
          <div style={{ display: 'flex', gap: 10 }}>
            <button
              className="btn btn-primary btn-full"
              onClick={() => navigate('/dashboard')}
            >
              🏠 Dashboard
            </button>
            <button
              className="btn btn-secondary btn-full"
              onClick={() => navigate('/history')}
            >
              📋 History
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
