require('dotenv').config();
const express  = require('express');
const http     = require('http');
const { Server } = require('socket.io');
const cors     = require('cors');
const mongoose = require('mongoose');
const path     = require('path');

const authRoutes  = require('./routes/auth');
const matchRoutes = require('./routes/matches');
const { setupGameSocket } = require('./socket/gameSocket');

const app    = express();
const server = http.createServer(app);

const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:3000';

const io = new Server(server, {
  cors: { origin: CLIENT_URL, methods: ['GET', 'POST'], credentials: true },
});

// ── Middleware ─────────────────────────────────────────────
app.use(cors({ origin: CLIENT_URL, credentials: true }));
app.use(express.json());

// ── API Routes ─────────────────────────────────────────────
app.use('/api/auth',    authRoutes);
app.use('/api/matches', matchRoutes);
app.get('/api/health',  (req, res) => res.json({ status: 'ok', message: 'Hand Cricket API running' }));

// ── Serve React build in production ───────────────────────
if (process.env.NODE_ENV === 'production') {
  const buildPath = path.join(__dirname, '..', 'client', 'build');
  app.use(express.static(buildPath));
  app.get('*', (req, res) => {
    res.sendFile(path.join(buildPath, 'index.html'));
  });
}

// ── Socket.IO Game Logic ───────────────────────────────────
setupGameSocket(io);

// ── MongoDB ────────────────────────────────────────────────
mongoose
  .connect(process.env.MONGO_URI || 'mongodb://localhost:27017/handcricket')
  .then(() => {
    console.log('✅  MongoDB connected');
    const PORT = process.env.PORT || 5000;
    server.listen(PORT, () =>
      console.log(`🏏  Hand Cricket server running on http://localhost:${PORT}`)
    );
  })
  .catch((err) => {
    console.error('❌  MongoDB connection error:', err.message);
    process.exit(1);
  });
