const mongoose = require('mongoose');

const inningSummarySchema = new mongoose.Schema({
  batsman: String,
  runs: { type: Number, default: 0 },
  balls: { type: Number, default: 0 },
  wickets: { type: Number, default: 0 },
  ballHistory: [Number], // each ball's result (runs scored or -1 for out)
});

const matchSchema = new mongoose.Schema(
  {
    player1: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    player2: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // null for vs Computer
    player1Name: { type: String, required: true },
    player2Name: { type: String, default: 'Computer' },
    isVsComputer: { type: Boolean, default: false },
    roomCode: { type: String },
    status: { type: String, enum: ['waiting', 'active', 'completed'], default: 'waiting' },
    winner: { type: String }, // username of winner or 'draw'
    winnerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    inning1: { type: inningSummarySchema },
    inning2: { type: inningSummarySchema },
    player1Score: { type: Number, default: 0 },
    player2Score: { type: Number, default: 0 },
    totalBalls: { type: Number, default: 6 },
    completedAt: { type: Date },
  },
  { timestamps: true }
);

// Virtual: strike rate for match
matchSchema.virtual('strikeRate').get(function () {
  const balls = this.inning1?.balls || 0;
  const runs = this.player1Score || 0;
  if (!balls) return 0;
  return +((runs / balls) * 100).toFixed(2);
});

module.exports = mongoose.model('Match', matchSchema);
