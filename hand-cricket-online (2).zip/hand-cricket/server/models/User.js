const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    username: { type: String, required: true, unique: true, trim: true, minlength: 3, maxlength: 20 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    stats: {
      totalMatches: { type: Number, default: 0 },
      wins: { type: Number, default: 0 },
      losses: { type: Number, default: 0 },
      bestScore: { type: Number, default: 0 },
      totalRunsScored: { type: Number, default: 0 },
      totalBallsFaced: { type: Number, default: 0 },
      totalWicketsTaken: { type: Number, default: 0 },
      totalBallsBowled: { type: Number, default: 0 },
    },
  },
  { timestamps: true }
);

// Hash password before save
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Compare password
userSchema.methods.comparePassword = function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

// Virtual: batting average
userSchema.virtual('battingAverage').get(function () {
  if (!this.stats.totalBallsFaced) return 0;
  return +(this.stats.totalRunsScored / (this.stats.totalBallsFaced / 6)).toFixed(2);
});

// Virtual: bowling average
userSchema.virtual('bowlingAverage').get(function () {
  if (!this.stats.totalWicketsTaken) return 0;
  return +(this.stats.totalRunsScored / this.stats.totalWicketsTaken).toFixed(2);
});

module.exports = mongoose.model('User', userSchema);
