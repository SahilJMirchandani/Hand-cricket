const router = require('express').Router();
const Match = require('../models/Match');
const { protect } = require('../middleware/auth');

// GET /api/matches/history  – logged-in user's match history
router.get('/history', protect, async (req, res) => {
  try {
    const matches = await Match.find({
      $or: [{ player1: req.user._id }, { player2: req.user._id }],
      status: 'completed',
    })
      .sort({ completedAt: -1 })
      .limit(20)
      .lean();

    const formatted = matches.map((m) => {
      const isP1 = String(m.player1) === String(req.user._id);
      const myScore = isP1 ? m.player1Score : m.player2Score;
      const oppScore = isP1 ? m.player2Score : m.player1Score;
      const oppName = isP1 ? m.player2Name : m.player1Name;
      const result = m.winner === req.user.username ? 'Win' : m.winner === 'draw' ? 'Draw' : 'Loss';
      const myInning = isP1 ? m.inning1 : m.inning2;
      const balls = myInning?.balls || 0;
      const strikeRate = balls ? +((myScore / balls) * 100).toFixed(1) : 0;
      return {
        _id: m._id,
        opponent: oppName,
        result,
        myScore,
        oppScore,
        isVsComputer: m.isVsComputer,
        strikeRate,
        wickets: myInning?.wickets || 0,
        date: m.completedAt || m.updatedAt,
      };
    });

    res.json({ matches: formatted });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/matches/:id – single match detail
router.get('/:id', protect, async (req, res) => {
  try {
    const match = await Match.findById(req.params.id).lean();
    if (!match) return res.status(404).json({ message: 'Match not found' });
    res.json({ match });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
