const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Match = require('../models/Match');

// In-memory room store: roomCode -> roomState
const rooms = new Map();

const TOTAL_BALLS = 6;
const TURN_SECONDS = 5;

function genCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function computerPick() {
  return Math.floor(Math.random() * 7); // 0-6
}

function createRoom(code, hostSocket, hostUser) {
  return {
    code,
    hostSocket,
    hostUser,   // { id, username }
    guestSocket: null,
    guestUser: null,
    isVsComputer: false,
    matchId: null,
    // game state
    inning: 1,
    batting: 'host',   // 'host' | 'guest'
    hostScore: 0,
    guestScore: 0,
    balls: 0,
    wickets: 0,
    hostPick: null,
    guestPick: null,
    turnTimer: null,
    ballHistory: [],
    inning1Summary: null,
  };
}

async function saveMatch(room, winnerId, winnerName) {
  try {
    const match = await Match.findById(room.matchId);
    if (!match) return;

    match.status = 'completed';
    match.winner = winnerName;
    match.winnerId = winnerId;
    match.player1Score = room.hostScore;
    match.player2Score = room.guestScore;
    match.completedAt = new Date();

    if (room.inning1Summary) {
      match.inning1 = room.inning1Summary;
    }
    match.inning2 = {
      batsman: room.batting === 'host' ? room.hostUser.username : room.guestUser?.username || 'Computer',
      runs: room.batting === 'host' ? room.hostScore : room.guestScore,
      balls: room.balls,
      wickets: room.wickets,
      ballHistory: room.ballHistory,
    };

    await match.save();

    // Update user stats for both players
    const updateStats = async (userId, myScore, oppScore, won) => {
      const user = await User.findById(userId);
      if (!user) return;
      user.stats.totalMatches += 1;
      if (won) user.stats.wins += 1;
      else user.stats.losses += 1;
      if (myScore > user.stats.bestScore) user.stats.bestScore = myScore;
      user.stats.totalRunsScored += myScore;
      user.stats.totalBallsFaced += TOTAL_BALLS;
      await user.save();
    };

    await updateStats(room.hostUser.id, room.hostScore, room.guestScore, winnerId === room.hostUser.id);
    if (!room.isVsComputer && room.guestUser) {
      await updateStats(room.guestUser.id, room.guestScore, room.hostScore, winnerId === room.guestUser.id);
    }
  } catch (err) {
    console.error('saveMatch error:', err.message);
  }
}

function clearTurnTimer(room) {
  if (room.turnTimer) {
    clearInterval(room.turnTimer);
    room.turnTimer = null;
  }
}

function setupGameSocket(io) {
  // Auth middleware for socket
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('No token'));
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.id).select('_id username stats');
      if (!user) return next(new Error('User not found'));
      socket.user = { id: String(user._id), username: user.username };
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    console.log(`🔌 ${socket.user.username} connected [${socket.id}]`);

    // ── CREATE ROOM ──────────────────────────────────────────
    socket.on('create_room', async () => {
      let code;
      do { code = genCode(); } while (rooms.has(code));

      const room = createRoom(code, socket.id, socket.user);
      rooms.set(code, room);
      socket.join(code);
      socket.emit('room_created', { code });
      console.log(`🏟️ Room ${code} created by ${socket.user.username}`);
    });

    // ── JOIN ROOM ────────────────────────────────────────────
    socket.on('join_room', async ({ code }) => {
      const room = rooms.get(code);
      if (!room) return socket.emit('error', { message: 'Room not found' });
      if (room.guestSocket) return socket.emit('error', { message: 'Room is full' });
      if (room.hostSocket === socket.id) return socket.emit('error', { message: 'You are the host' });

      room.guestSocket = socket.id;
      room.guestUser = socket.user;
      socket.join(code);

      // Create match record
      const match = await Match.create({
        player1: room.hostUser.id,
        player2: room.guestUser.id,
        player1Name: room.hostUser.username,
        player2Name: room.guestUser.username,
        roomCode: code,
        status: 'active',
        totalBalls: TOTAL_BALLS,
      });
      room.matchId = String(match._id);

      io.to(code).emit('game_start', {
        roomCode: code,
        hostUser: room.hostUser,
        guestUser: room.guestUser,
        batting: room.batting,
        inning: room.inning,
        totalBalls: TOTAL_BALLS,
      });

      startTurn(io, room);
    });

    // ── VS COMPUTER ──────────────────────────────────────────
    socket.on('start_vs_computer', async () => {
      let code;
      do { code = genCode(); } while (rooms.has(code));

      const room = createRoom(code, socket.id, socket.user);
      room.isVsComputer = true;
      room.guestUser = { id: null, username: 'Computer' };
      rooms.set(code, room);
      socket.join(code);

      const match = await Match.create({
        player1: socket.user.id,
        player1Name: socket.user.username,
        player2Name: 'Computer',
        isVsComputer: true,
        status: 'active',
        totalBalls: TOTAL_BALLS,
      });
      room.matchId = String(match._id);

      socket.emit('game_start', {
        roomCode: code,
        hostUser: room.hostUser,
        guestUser: room.guestUser,
        batting: room.batting,
        inning: room.inning,
        totalBalls: TOTAL_BALLS,
      });

      startTurn(io, room);
    });

    // ── PLAYER PICK ──────────────────────────────────────────
    socket.on('player_pick', ({ code, pick }) => {
      const room = rooms.get(code);
      if (!room) return;

      const isHost = socket.id === room.hostSocket;
      const isGuest = socket.id === room.guestSocket;
      if (!isHost && !isGuest) return;

      if (isHost && room.hostPick === null) room.hostPick = pick;
      if (isGuest && room.guestPick === null) room.guestPick = pick;

      // For vs Computer: computer picks immediately
      if (room.isVsComputer && room.hostPick !== null) {
        room.guestPick = computerPick();
      }

      // Tell player their pick was registered
      socket.emit('pick_registered', { pick });

      // If both picked, resolve
      if (room.hostPick !== null && room.guestPick !== null) {
        clearTurnTimer(room);
        resolveTurn(io, room);
      }
    });

    // ── DISCONNECT ───────────────────────────────────────────
    socket.on('disconnect', () => {
      console.log(`⚡ ${socket.user.username} disconnected`);
      for (const [code, room] of rooms.entries()) {
        if (room.hostSocket === socket.id || room.guestSocket === socket.id) {
          clearTurnTimer(room);
          io.to(code).emit('opponent_disconnected', { username: socket.user.username });
          rooms.delete(code);
        }
      }
    });
  });

  // ── TURN TIMER ─────────────────────────────────────────────
  function startTurn(io, room) {
    room.hostPick = null;
    room.guestPick = null;
    let seconds = TURN_SECONDS;

    io.to(room.code).emit('turn_start', { seconds: TURN_SECONDS, inning: room.inning, balls: room.balls });

    room.turnTimer = setInterval(() => {
      seconds--;
      io.to(room.code).emit('timer_tick', { seconds });

      if (seconds <= 0) {
        clearInterval(room.turnTimer);
        room.turnTimer = null;
        // Auto-pick random if not picked
        if (room.hostPick === null) room.hostPick = Math.floor(Math.random() * 7);
        if (room.guestPick === null) {
          room.guestPick = room.isVsComputer ? computerPick() : Math.floor(Math.random() * 7);
        }
        resolveTurn(io, room);
      }
    }, 1000);
  }

  // ── RESOLVE TURN ───────────────────────────────────────────
  function resolveTurn(io, room) {
    const h = room.hostPick;
    const g = room.guestPick;
    const isOut = h === g;

    let runsThisBall = 0;
    let outcome = 'runs';

    if (isOut) {
      outcome = 'out';
      room.wickets += 1;
      room.ballHistory.push(-1);
    } else {
      // Batting player scores runs equal to their own pick
      runsThisBall = room.batting === 'host' ? h : g;
      if (room.batting === 'host') room.hostScore += runsThisBall;
      else room.guestScore += runsThisBall;
      room.ballHistory.push(runsThisBall);
    }

    room.balls += 1;

    io.to(room.code).emit('turn_result', {
      hostPick: h,
      guestPick: g,
      outcome,
      runsThisBall,
      hostScore: room.hostScore,
      guestScore: room.guestScore,
      balls: room.balls,
      wickets: room.wickets,
      inning: room.inning,
      totalBalls: TOTAL_BALLS,
    });

    // Check inning/game end (out OR all balls bowled)
    const inningShouldEnd = isOut || room.balls >= TOTAL_BALLS;

    // Also end inning 2 early if target already exceeded
    const target = room.inning === 2 ? (room.inning1Summary?.runs ?? 0) + 1 : null;
    const chaseWon = room.inning === 2 && (room.batting === 'host' ? room.hostScore : room.guestScore) >= target;

    if (inningShouldEnd || chaseWon) {
      setTimeout(() => transitionOrEnd(io, room), 1000);
    } else {
      setTimeout(() => startTurn(io, room), 1200);
    }
  }

  // ── INNING TRANSITION / GAME END ───────────────────────────
  async function transitionOrEnd(io, room) {
    if (room.inning === 1) {
      // Save inning 1 summary
      room.inning1Summary = {
        batsman: room.batting === 'host' ? room.hostUser.username : room.guestUser.username,
        runs: room.batting === 'host' ? room.hostScore : room.guestScore,
        balls: room.balls,
        wickets: room.wickets,
        ballHistory: [...room.ballHistory],
      };

      // Switch batting
      room.inning = 2;
      room.batting = room.batting === 'host' ? 'guest' : 'host';
      room.balls = 0;
      room.wickets = 0;
      room.hostPick = null;
      room.guestPick = null;
      room.ballHistory = [];

      const target = room.inning1Summary.runs + 1;

      io.to(room.code).emit('inning_change', {
        inning: 2,
        batting: room.batting,
        hostScore: room.hostScore,
        guestScore: room.guestScore,
        target,
      });

      setTimeout(() => startTurn(io, room), 1500);
    } else {
      // Game over – determine winner
      let winnerId = null;
      let winnerName = 'draw';

      if (room.hostScore > room.guestScore) {
        winnerId = room.hostUser.id;
        winnerName = room.hostUser.username;
      } else if (room.guestScore > room.hostScore) {
        winnerId = room.guestUser?.id || null;
        winnerName = room.guestUser?.username || 'Computer';
      }

      io.to(room.code).emit('game_over', {
        winner: winnerName,
        winnerId,
        hostScore: room.hostScore,
        guestScore: room.guestScore,
        hostUser: room.hostUser,
        guestUser: room.guestUser,
        isVsComputer: room.isVsComputer,
      });

      await saveMatch(room, winnerId, winnerName);
      clearTurnTimer(room);
      rooms.delete(room.code);
    }
  }
}

module.exports = { setupGameSocket };
